// script.js — populate product list and provide simple interactions
const products = [
  {
    name: "Signature Bitter Blend 750ml",
    price: "TSh 28,000",
    img: "https://images.example.com/signature-bitter-750.jpg",
    note: "Link to image only — host externally."
  },
  {
    name: "Premium Malt 330ml (6-pack)",
    price: "TSh 35,000",
    img: "https://images.example.com/premium-malt-6pack.jpg",
    note: "6-pack recommended for promotions."
  },
  {
    name: "Limited Edition Spirit 500ml",
    price: "TSh 85,000",
    img: "https://images.example.com/limited-spirit-500.jpg",
    note: "Use image link for carousel on social."
  }
];

function el(tag, cls, txt){const e=document.createElement(tag); if(cls) e.className=cls; if(txt) e.textContent=txt; return e;}

function renderProducts(){
  const list = document.getElementById('product-list');
  products.forEach(p=>{
    const card = el('div','product');
    card.appendChild(el('div','name', p.name));
    card.appendChild(el('div','price', p.price));
    const link = document.createElement('a');
    link.href = p.img;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.className = 'link';
    link.textContent = 'Open image link';
    card.appendChild(link);
    card.appendChild(el('div','muted', p.note));
    list.appendChild(card);
  });
}

document.addEventListener('DOMContentLoaded', ()=>{
  renderProducts();
});