# Bland Growing — Website Scaffold

This is a small, polished, dark-themed website scaffold for **Bland Growing**.
It follows the style direction: dark · rich · premium · calm luxury · minimal — with no images embedded (only external image links).

## What is included
- `index.html` — Main page (responsive, minimal)
- `styles.css` — Dark, premium styling
- `script.js` — Product population and small interactions
- `README.md` — This file
- `LICENSE` — MIT license (simple)
- `assets/placeholder.txt` — note about hosting external images

## Deployment (GitHub Pages)
1. Create a new GitHub repo (e.g. `bland-growing`).
2. Upload these files to the repository root.
3. On GitHub go to **Settings → Pages** and set the branch to main (or gh-pages) and folder `/ (root)`.
4. After a minute your site will be available at `https://<your-username>.github.io/<repo-name>/`

## Customize
- Replace product objects in `script.js` with your real product lines, image URLs, and prices.
- Update contact details in `index.html`.
- If you want images hosted, add them to `assets/` and update links accordingly.

---
Designed for Professor Nickolas — ready to be zipped and uploaded.
